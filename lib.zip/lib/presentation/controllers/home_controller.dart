import 'dart:async';
import 'dart:developer';

import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:share_plus/share_plus.dart';
import '../../data/repositories/auth_repository.dart';
import '../../data/repositories/video_repository.dart';
import '../../data/repositories/favorites_repository.dart';
import '../../data/repositories/university_stats_repository.dart';
import '../../data/repositories/engagement_repository.dart';
import '../../data/models/video_model.dart';
import '../../data/models/playlist_model.dart';
import '../../data/models/university_model.dart';
import '../../data/models/university_stats_model.dart';
import '../../data/models/video_engagement_model.dart';

class HomeController extends GetxController {
  final VideoRepository videoRepository;
  final FavoritesRepository favoritesRepository;
  final UniversityStatsRepository universityStatsRepository;
  final AuthRepository authRepository;
  final EngagementRepository engagementRepository;

  HomeController({
    required this.videoRepository,
    required this.favoritesRepository,
    required this.universityStatsRepository,
    required this.authRepository,
    required this.engagementRepository,
  });

  // ─── State ─────────────────────────────────────────────────────────────────

  final videos = <VideoModel>[].obs;
  final playlists = <PlaylistModel>[].obs;
  final favoriteIds = <String>[].obs;
  final universities = <UniversityModel>[].obs;

  final isLoading = false.obs;
  final isPlaylistsLoading = false.obs;
  final isUniversitiesLoading = false.obs;

  final errorMessage = ''.obs;
  final playlistsError = ''.obs;

  final selectedTab = 0.obs;
  final selectedIndex = 0.obs;
  final selectedUniversity = Rxn<UniversityModel>();

  final statsMostWatched = <UniversityStatsModel>[].obs;
  final statsMostLiked = <UniversityStatsModel>[].obs;
  final statsPopularInApp = <UniversityStatsModel>[].obs;
  final statsMostFavorited = <UniversityStatsModel>[].obs;
  final statsActiveLast30 = <UniversityStatsModel>[].obs;
  final statsBiggestChannels = <UniversityStatsModel>[].obs;
  final statsRichestArchive = <UniversityStatsModel>[].obs;
  final statsNewlyDiscovered = <UniversityStatsModel>[].obs;

  final isStatsLoading = false.obs;

  final videosTrending = <VideoEngagementModel>[].obs;
  final videosMostWatched = <VideoEngagementModel>[].obs;
  final videosMostLiked = <VideoEngagementModel>[].obs;
  final videosMostFavorited = <VideoEngagementModel>[].obs;
  final videosMostCommented = <VideoEngagementModel>[].obs;
  final videosNewUndiscovered = <VideoEngagementModel>[].obs;

  final isVideoSectionsLoading = false.obs;

  final showAuthRequired = false.obs;

  // ─── Like local cache ─────────────────────────────────────────────────────
  // key: videoId → value: true/false
  // Sadece kullanıcı dokunduğu videolar için tutulur.
  // Uygulama başında hiçbir şey çekilmez; ilk dokunuşta Supabase'e bir kez
  // sorulur, sonraki dokunuşlarda bu cache'ten bakılır.
  final _likeCache = <String, bool>{};
  final _likeCacheLoading = <String>{};  // DB sorgusu sürerken çift tık önleme
  final _likeProcessing = <String>{};    // toggle işlemi sürerken önleme
  final _shareProcessing = <String>{};

  // Rx set: sadece widget'ların rebuild alması için
  final _likedIds = <String>{}.obs;
  final _likeLoadingIds = <String>{}.obs;
  final _shareLoadingIds = <String>{}.obs;

  // ─── Yardımcılar ─────────────────────────────────────────────────────────

  String? get _currentUserId => authRepository.currentUserId;
  bool get isLoggedIn => authRepository.isLoggedIn;

  late final StreamSubscription<FavoriteChange> _favoriteSubscription;

  // ─── Lifecycle ────────────────────────────────────────────────────────────

  @override
  void onInit() {
    super.onInit();
    _favoriteSubscription = favoritesRepository.onFavoriteChanged.listen(_onFavoriteChanged);
  }

  @override
  void onReady() {
    super.onReady();
    loadUniversitiesAndPlaylists();
    loadVideos();
    loadFavorites();
    loadUniversityStats();
    loadVideoSections();
  }

  @override
  void onClose() {
    _favoriteSubscription.cancel();
    super.onClose();
  }

  void _onFavoriteChanged(FavoriteChange event) {
    if (event.isFavorite) {
      if (!favoriteIds.contains(event.videoId)) favoriteIds.add(event.videoId);
    } else {
      favoriteIds.remove(event.videoId);
    }
  }

  // ─── Stats ────────────────────────────────────────────────────────────────

  Future<void> loadUniversityStats() async {
    try {
      isStatsLoading.value = true;
      final bundle = await universityStatsRepository.getAllStats();
      statsMostWatched.value    = bundle['most_watched']        ?? [];
      statsMostLiked.value      = bundle['most_liked']          ?? [];
      statsPopularInApp.value   = bundle['popular_in_app']      ?? [];
      statsMostFavorited.value  = bundle['most_favorited']      ?? [];
      statsActiveLast30.value   = bundle['most_active_last_30'] ?? [];
      statsBiggestChannels.value= bundle['biggest_channels']    ?? [];
      statsRichestArchive.value = bundle['richest_archive']     ?? [];
      statsNewlyDiscovered.value= bundle['newly_discovered']    ?? [];
    } catch (e) {
      log('loadUniversityStats error: $e');
    } finally {
      isStatsLoading.value = false;
    }
  }

  Future<void> loadVideoSections() async {
    try {
      isVideoSectionsLoading.value = true;
      final bundle = await videoRepository.getAllVideoSections();
      videosTrending.value       = bundle['trending']         ?? [];
      videosMostWatched.value    = bundle['most_watched']     ?? [];
      videosMostLiked.value      = bundle['most_liked']       ?? [];
      videosMostFavorited.value  = bundle['most_favorited']   ?? [];
      videosMostCommented.value  = bundle['most_commented']   ?? [];
      videosNewUndiscovered.value= bundle['new_undiscovered'] ?? [];
    } catch (e) {
      log('loadVideoSections error: $e');
    } finally {
      isVideoSectionsLoading.value = false;
    }
  }

  Future<void> loadUniversitiesAndPlaylists() async {
    try {
      isUniversitiesLoading.value = true;
      isPlaylistsLoading.value = true;
      playlistsError.value = '';
      final rows = await videoRepository.getUniversitiesAndPlaylists();
      universities.value = rows.map((r) => UniversityModel.fromSupabase(r)).toList();
      playlists.value = rows.map((r) => PlaylistModel.fromUniversity(
        r,
        videoCount: (r['video_count'] as int?) ?? 0,
        thumbnailUrl: r['thumbnail_url'] as String? ?? '',
      )).toList();
    } catch (e) {
      log('loadUniversitiesAndPlaylists error: $e');
      playlistsError.value = 'Üniversiteler yüklenemedi.';
    } finally {
      isUniversitiesLoading.value = false;
      isPlaylistsLoading.value = false;
    }
  }

  Future<void> selectUniversity(UniversityModel? university) async {
    selectedUniversity.value = university;
    await loadVideos();
  }

  Future<void> loadVideos() async {
    try {
      isLoading.value = true;
      errorMessage.value = '';
      final uni = selectedUniversity.value;
      videos.value = uni != null
          ? await videoRepository.getVideosByUniversity(uni.id!)
          : await videoRepository.getLatestVideosPerUniversity();
    } catch (e) {
      errorMessage.value = 'Videolar yüklenemedi.';
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> refreshVideos() async {
    try {
      isLoading.value = true;
      errorMessage.value = '';
      await videoRepository.refreshVideos();
      await loadVideos();
      await loadVideoSections();
    } catch (e) {
      errorMessage.value = 'Videolar yenilenemedi.';
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> loadPlaylists() => loadUniversitiesAndPlaylists();

  Future<void> loadFavorites() async {
    try {
      final userId = _currentUserId;
      if (userId == null) return;
      favoriteIds.value = await favoritesRepository.getFavoriteVideoIds(userId);
    } catch (e) {
      log('loadFavorites error: $e');
    }
  }

  bool isFavorite(String videoId) => favoriteIds.contains(videoId);

  Future<void> toggleFavorite(String videoId) async {
    final userId = _currentUserId;
    if (userId == null) { showAuthRequired.value = true; return; }

    try {
      if (isFavorite(videoId)) {
        await favoritesRepository.removeFavorite(userId, videoId);
        await favoritesRepository.removeFavoriteVideoLocally(videoId);
      } else {
        await favoritesRepository.addFavorite(userId, videoId);
        final video = videos.firstWhereOrNull((v) => v.videoId == videoId);
        if (video != null) await favoritesRepository.saveFavoriteVideoLocally(video);
      }
    } catch (e) {
      log('toggleFavorite error: $e');
    }
  }

  // ─── Beğeni — on-demand cache yaklaşımı ──────────────────────────────────
  //
  // İlk dokunuşta:
  //   1. Buton devre dışı (loading göster)
  //   2. Supabase'e tek satır sorgu: "bu user bu videoyu beğenmiş mi?"
  //   3. Sonuç cache'e yazılır
  //   4. Toggle yapılır → optimistic update + Supabase write
  //
  // Sonraki dokunuşlarda:
  //   Cache'te var → direkt toggle, DB sorgusu yok.
  //
  // Bellek: Kullanıcı kaç videoya dokunursa o kadar bool tutulur.
  // 10.000 entry bile ~80KB → önemsiz.

  bool isLiked(String videoId) => _likedIds.contains(videoId);
  bool isLikeLoading(String videoId) => _likeLoadingIds.contains(videoId);
  bool isShareLoading(String videoId) => _shareLoadingIds.contains(videoId);

  Future<void> toggleLike(String videoId) async {
    final userId = _currentUserId;
    if (userId == null) { showAuthRequired.value = true; return; }
    if (_likeProcessing.contains(videoId)) return;
    if (_likeCacheLoading.contains(videoId)) return;

    _likeProcessing.add(videoId);
    _likeLoadingIds.add(videoId);

    try {
      // Cache'te yoksa ilk kez dokunuluyor: DB'ye sor
      if (!_likeCache.containsKey(videoId)) {
        _likeCacheLoading.add(videoId);
        try {
          _likeCache[videoId] = await engagementRepository.isLiked(userId, videoId);
        } finally {
          _likeCacheLoading.remove(videoId);
        }
        // Cache dolduktan sonra Rx set'i güncelle (ilk render)
        if (_likeCache[videoId]!) _likedIds.add(videoId);
      }

      final wasLiked = _likeCache[videoId]!;

      // Optimistic update
      _likeCache[videoId] = !wasLiked;
      if (wasLiked) {
        _likedIds.remove(videoId);
      } else {
        _likedIds.add(videoId);
      }

      // Supabase write
      try {
        if (wasLiked) {
          await engagementRepository.removeLike(userId, videoId);
        } else {
          await engagementRepository.addLike(userId, videoId);
        }
      } catch (e) {
        // Hata → geri al
        _likeCache[videoId] = wasLiked;
        if (wasLiked) {
          _likedIds.add(videoId);
        } else {
          _likedIds.remove(videoId);
        }
        log('[HomeController] toggleLike write error: $e');
      }
    } finally {
      _likeLoadingIds.remove(videoId);
      _likeProcessing.remove(videoId);
    }
  }

  // ─── Paylaşım ─────────────────────────────────────────────────────────────

  Future<void> shareVideo(VideoModel video) async {
    if (_shareProcessing.contains(video.videoId)) return;
    _shareProcessing.add(video.videoId);
    _shareLoadingIds.add(video.videoId);

    final videoUrl = 'https://www.youtube.com/watch?v=${video.videoId}';
    final text = '${video.title}\n$videoUrl';

    try {
      await SharePlus.instance.share(ShareParams(text: text, subject: video.title));
      final userId = _currentUserId;
      if (userId != null) {
        await engagementRepository.recordShare(userId, video.videoId);
      }
    } catch (e) {
      log('[HomeController] shareVideo fallback to clipboard: $e');
      await Clipboard.setData(ClipboardData(text: videoUrl));
      Get.snackbar(
        'Bağlantı Kopyalandı',
        'Video bağlantısı panoya kopyalandı.',
        snackPosition: SnackPosition.BOTTOM,
      );
    } finally {
      _shareLoadingIds.remove(video.videoId);
      _shareProcessing.remove(video.videoId);
    }
  }

  // ─── Navigasyon ──────────────────────────────────────────────────────────

  void changeTab(int index) => selectedIndex.value = index;

  String get appBarTitle {
    final uni = selectedUniversity.value;
    if (uni == null) return 'ÜniTV';
    final name = uni.name ?? 'ÜniTV';
    if (name.length > 20) return '${name.substring(0, 18)}…';
    return name;
  }
}