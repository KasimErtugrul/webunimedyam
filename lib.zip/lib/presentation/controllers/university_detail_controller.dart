// lib/presentation/controllers/university_detail_controller.dart
//
// BUG FIX özeti:
//   1) toggleFavorite() artık addFavorite/removeFavorite'in bool dönüşünü
//      kullanıyor. Hata durumunda snackbar gösteriyor.
//      Önceki kodda repository rethrow yapıyordu; bu controller yakalıyor
//      ama UI mesajı veriyordu. Ancak repository rethrow kaldırıldığından
//      artık bool kontrol edilmeli.
//   2) isFavorite optimistic olarak repository event'inden geliyor
//      (stream listener). toggleFavorite() içinde manuel set() yok;
//      bu hem tutarlı hem de çift kaynak sorununu önlüyor.

import 'dart:developer';
import 'dart:async';

import 'package:get/get.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../data/models/university_model.dart';
import '../../data/models/video_model.dart';
import '../../data/repositories/university_favorites_repository.dart';
import '../../data/repositories/video_repository.dart';

class UniversityDetailController extends GetxController {
  final VideoRepository videoRepository;
  final UniversityFavoritesRepository universityFavoritesRepository;

  UniversityDetailController({
    required this.videoRepository,
    required this.universityFavoritesRepository,
  });

  final university = Rxn<UniversityModel>();
  final videos = <VideoModel>[].obs;
  final isLoading = true.obs;
  final errorMessage = ''.obs;

  final isFavorite = false.obs;
  final isFavoriteLoading = false.obs;

  late final StreamSubscription<UniversityFavoriteChange> _favSub;

  List<VideoModel> get videoOnly => videos.where((v) => !v.isShorts).toList();
  List<VideoModel> get shortsOnly => videos.where((v) => v.isShorts).toList();

  @override
  void onInit() {
    super.onInit();

    // Favori değişimlerini stream'den dinle — optimistic update buradan geliyor.
    // BUG FIX: isFavorite manuel set edilmiyor; stream tek kaynak.
    _favSub = universityFavoritesRepository.onFavoriteChanged.listen((event) {
      try {
        if (event.universityId == university.value?.id) {
          isFavorite.value = event.isFavorite;
        }
      } catch (e, stacktrace) {
        log(
          'Favori değişikliği işlenirken hata oluştu: $e',
          error: e,
          stackTrace: stacktrace,
        );
      }
    });

    try {
      final args = Get.arguments;
      if (args is UniversityModel) {
        university.value = args;
        _loadFavoriteStatus();
        loadVideos();
      } else if (args is int) {
        _loadUniversityById(args);
      } else {
        errorMessage.value = 'Üniversite bilgisi alınamadı.';
        isLoading.value = false;
      }
    } catch (e, stacktrace) {
      log(
        'UniversityDetail başlatılırken hata oluştu: $e',
        error: e,
        stackTrace: stacktrace,
      );
      errorMessage.value = 'Üniversite bilgisi alınamadı.';
      isLoading.value = false;
    }
  }

  @override
  void onClose() {
    try {
      _favSub.cancel();
    } catch (e, stacktrace) {
      log(
        'Favori aboneliği iptal edilirken hata oluştu: $e',
        error: e,
        stackTrace: stacktrace,
      );
    }
    super.onClose();
  }

  // ─── Yükleme ──────────────────────────────────────────────────────────────

  Future<void> _loadUniversityById(int id) async {
    try {
      isLoading.value = true;
      errorMessage.value = '';
      university.value = await videoRepository.getUniversityById(id);
      await _loadFavoriteStatus();
      await loadVideos();
    } catch (e, stacktrace) {
      log(
        'Üniversite ID ile yüklenirken hata oluştu: $e',
        error: e,
        stackTrace: stacktrace,
      );
      errorMessage.value = 'Üniversite bilgileri yüklenemedi.';
      isLoading.value = false;
    }
  }

  Future<void> loadVideos() async {
    final id = university.value?.id;
    if (id == null) return;
    try {
      isLoading.value = true;
      errorMessage.value = '';
      videos.value = await videoRepository.getVideosByUniversity(id);
    } catch (e, stacktrace) {
      log(
        'Üniversite videoları yüklenirken hata oluştu: $e',
        error: e,
        stackTrace: stacktrace,
      );
      errorMessage.value = 'Videolar yüklenemedi.';
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> _loadFavoriteStatus() async {
    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      final uniId = university.value?.id;
      if (userId == null || uniId == null) return;
      isFavorite.value = await universityFavoritesRepository
          .isUniversityFavorited(userId, uniId);
    } catch (e, stacktrace) {
      log(
        'Favori durumu yüklenirken hata oluştu: $e',
        error: e,
        stackTrace: stacktrace,
      );
    }
  }

  // ─── Favori Toggle ─────────────────────────────────────────────────────────

  /// BUG FIX: addFavorite / removeFavorite artık bool döndürüyor.
  /// Hata durumunda (false) snackbar gösteriliyor.
  /// isFavorite optimistic olarak repository event stream'inden geliyor;
  /// burada manuel set yok — stream tek kaynak of truth.
  Future<void> toggleFavorite() async {
    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      final uni = university.value;
      if (userId == null || uni?.id == null) {
        Get.snackbar(
          'Giriş Gerekli',
          'Favorilere eklemek için giriş yapmalısınız.',
          snackPosition: SnackPosition.BOTTOM,
        );
        return;
      }

      if (isFavoriteLoading.value) return;
      isFavoriteLoading.value = true;

      try {
        bool success;
        if (isFavorite.value) {
          success = await universityFavoritesRepository.removeFavorite(
            userId,
            uni!.id!,
          );
          if (success) {
            Get.snackbar(
              'Favorilerden Çıkarıldı',
              '${uni.name} favorilerden çıkarıldı.',
              snackPosition: SnackPosition.BOTTOM,
              duration: const Duration(seconds: 2),
            );
          } else {
            Get.snackbar(
              'Hata',
              'İşlem gerçekleştirilemedi. Lütfen tekrar deneyin.',
              snackPosition: SnackPosition.BOTTOM,
            );
          }
        } else {
          success = await universityFavoritesRepository.addFavorite(
            userId,
            uni!.id!,
            university: uni,
          );
          if (success) {
            Get.snackbar(
              'Favorilere Eklendi',
              '${uni.name} favorilerinize eklendi.',
              snackPosition: SnackPosition.BOTTOM,
              duration: const Duration(seconds: 2),
            );
          } else {
            Get.snackbar(
              'Hata',
              'İşlem gerçekleştirilemedi. Lütfen tekrar deneyin.',
              snackPosition: SnackPosition.BOTTOM,
            );
          }
        }
      } catch (e, stacktrace) {
        // Repository artık throw etmiyor ama savunmacı olalım
        log(
          'Favori toggle işlemi sırasında beklenmeyen hata: $e',
          error: e,
          stackTrace: stacktrace,
        );
        Get.snackbar(
          'Hata',
          'İşlem gerçekleştirilemedi. Lütfen tekrar deneyin.',
          snackPosition: SnackPosition.BOTTOM,
        );
      } finally {
        isFavoriteLoading.value = false;
      }
    } catch (e, stacktrace) {
      log(
        'Favori toggle işlemi sırasında hata oluştu: $e',
        error: e,
        stackTrace: stacktrace,
      );
    }
  }

  // ─── Yardımcı Formatlar ────────────────────────────────────────────────────

  String get formattedSubscriberCount {
    try {
      final count = university.value?.subscriberCount ?? 0;
      if (count >= 1000000) {
        return '${(count / 1000000).toStringAsFixed(1)}M';
      } else if (count >= 1000) {
        return '${(count / 1000).toStringAsFixed(0)}K';
      }
      return count.toString();
    } catch (e, stacktrace) {
      log(
        'Abone sayısı formatlanırken hata oluştu: $e',
        error: e,
        stackTrace: stacktrace,
      );
      return '0';
    }
  }

  String get formattedViewCount {
    try {
      final count = university.value?.viewCount ?? 0;
      if (count >= 1000000) {
        return '${(count / 1000000).toStringAsFixed(1)}M';
      } else if (count >= 1000) {
        return '${(count / 1000).toStringAsFixed(0)}K';
      }
      return count.toString();
    } catch (e, stacktrace) {
      log(
        'Görüntülenme sayısı formatlanırken hata oluştu: $e',
        error: e,
        stackTrace: stacktrace,
      );
      return '0';
    }
  }
}
