// lib/presentation/controllers/profile_controller.dart

import 'dart:developer';
import 'package:get/get.dart';
import '../../data/repositories/auth_repository.dart';
import '../../data/models/profile_model.dart';
import 'settings_controller.dart';

class ProfileController extends GetxController {
  final AuthRepository authRepository;

  ProfileController({required this.authRepository});

  // ─── Profil & Ayarlar ─────────────────────────────────────────────────────
  final profile = Rxn<ProfileModel>();
  final isLoading = false.obs;

  final successMessage = RxnString();
  final errorMessage = RxnString();

  // ─── Kimlik ───────────────────────────────────────────────────────────────

  String? get _currentUserId => authRepository.currentUserId;

  /// Route arguments'tan gelen hedef userId.
  /// null ise kendi profilimiz demektir.
  String? get targetUserId {
    final args = Get.arguments as Map<String, dynamic>?;
    return args?['userId'] as String?;
  }

  @override
  void onInit() {
    super.onInit();
    loadProfile();
  }

  /// Kendi profilimiz mi görüntülüyoruz?
  bool get isOwnProfile {
    final target = targetUserId;
    return target == null || target == _currentUserId;
  }

  // ─── Profil Yükleme ──────────────────────────────────────────────────────

  Future<void> loadProfile() async {
    try {
      isLoading.value = true;

      if (isOwnProfile) {
        profile.value = await authRepository.getProfile();
      } else {
        final tid = targetUserId;
        if (tid != null) {
          profile.value = await authRepository.getProfileById(tid);
        }
      }
    } catch (e, stacktrace) {
      log(
        'Profil yüklenirken hata oluştu: $e',
        error: e,
        stackTrace: stacktrace,
      );
      errorMessage.value = 'Profil yüklenemedi.';
    } finally {
      isLoading.value = false;
    }

    // Profil yüklenince SettingsController'ı senkronize et
    try {
      final p = profile.value;
      if (p != null && Get.isRegistered<SettingsController>()) {
        Get.find<SettingsController>().profileVisibility.value =
            p.profileVisibility;
      }
    } catch (e, stacktrace) {
      log(
        'SettingsController senkronizasyonu sırasında hata oluştu: $e',
        error: e,
        stackTrace: stacktrace,
      );
    }
  }

  // ─── Profil Güncelleme ────────────────────────────────────────────────────

  Future<void> updateProfile({
    String? username,
    String? fullName,
    String? avatarUrl,
  }) async {
    if (!isOwnProfile) {
      errorMessage.value = 'Bu profili düzenleme yetkiniz yok.';
      return;
    }

    final current = profile.value;
    if (current == null) return;

    try {
      final updated = current.copyWith(
        username: username,
        fullName: fullName,
        avatarUrl: avatarUrl,
      );
      await authRepository.updateProfile(updated);
      profile.value = updated;
      successMessage.value = 'Profil güncellendi.';
    } catch (e, stacktrace) {
      log(
        'Profil güncellenirken hata oluştu: $e',
        error: e,
        stackTrace: stacktrace,
      );
      errorMessage.value = 'Profil güncellenemedi.';
    }
  }

  // ─── Yardımcılar ──────────────────────────────────────────────────────────

  bool get isLoggedIn => authRepository.isLoggedIn;

  Future<void> refreshProfile() async {
    try {
      await loadProfile();
    } catch (e, stacktrace) {
      log(
        'Profil yenilenirken hata oluştu: $e',
        error: e,
        stackTrace: stacktrace,
      );
    }
  }
}
