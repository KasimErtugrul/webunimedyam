import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../../app/themes/app_theme.dart';
import '../../../../data/models/video_model.dart';

class YoutubeMetaWidget extends StatelessWidget {
  final VideoModel video;
  const YoutubeMetaWidget({super.key, required this.video});

  static const _ytRed = Color(0xFFFF0000);

  String _fmtCount(int n) {
    if (n >= 1000000) return '${(n / 1000000).toStringAsFixed(1)}M';
    if (n >= 1000) return '${(n / 1000).toStringAsFixed(1)}B';
    return '$n';
  }

  String _fmtDate(DateTime d) =>
      '${d.day.toString().padLeft(2, '0')}.${d.month.toString().padLeft(2, '0')}.${d.year}';

  @override
  Widget build(BuildContext context) {
    final sec = AppTheme.textSec(context);
    final isDark = AppTheme.isDark(context);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        // ── Bölüm Başlığı ──────────────────────────────────────────────
        Row(
          children: [
            Expanded(
              child: Divider(
                color: sec.withValues(alpha: 0.12),
                thickness: 0.8.h,
              ),
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 10.w),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // YouTube mini play-button
                  Container(
                    padding: EdgeInsets.all(2.5.r),
                    decoration: BoxDecoration(
                      color: _ytRed,
                      borderRadius: BorderRadius.circular(3.r),
                    ),
                    child: Icon(
                      Icons.play_arrow_rounded,
                      size: 9.sp,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(width: 5.w),
                  Text(
                    'YouTube',
                    style: TextStyle(
                      color: sec.withValues(alpha: 0.5),
                      fontSize: 10.sp,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 0.5,
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Divider(
                color: sec.withValues(alpha: 0.12),
                thickness: 0.8.h,
              ),
            ),
          ],
        ),

        SizedBox(height: 10.h),

        // ── İstatistik Paneli ──────────────────────────────────────────
        Container(
          width: double.infinity,
          clipBehavior: Clip.antiAlias,
          decoration: BoxDecoration(
            color: isDark
                ? Colors.white.withValues(alpha: 0.04)
                : Colors.black.withValues(alpha: 0.03),
            borderRadius: BorderRadius.circular(10.r),
          ),
          child: IntrinsicHeight(
            child: Row(
              children: [
                // Sol accent çizgi
                Container(width: 3.w, color: _ytRed.withValues(alpha: 0.55)),

                // İçerik
                Expanded(
                  child: Padding(
                    padding: EdgeInsets.symmetric(
                      horizontal: 12.w,
                      vertical: 10.h,
                    ),
                    child: Row(
                      children: [
                        // Görüntülenme
                        if (video.viewCount > 0)
                          _buildStat(
                            icon: Icons.visibility_outlined,
                            value: _fmtCount(video.viewCount),
                            label: 'görüntülenme',
                            sec: sec,
                          ),

                        // Nokta ayırıcı
                        if (video.viewCount > 0 && video.likeCount > 0)
                          Padding(
                            padding: EdgeInsets.symmetric(horizontal: 8.w),
                            child: Container(
                              width: 3.r,
                              height: 3.r,
                              decoration: BoxDecoration(
                                color: sec.withValues(alpha: 0.3),
                                shape: BoxShape.circle,
                              ),
                            ),
                          ),

                        // Beğeni
                        if (video.likeCount > 0)
                          _buildStat(
                            icon: Icons.thumb_up_off_alt_rounded,
                            value: _fmtCount(video.likeCount),
                            label: 'beğeni',
                            sec: sec,
                          ),

                        const Spacer(),

                        // Süre · Tarih
                        Text(
                          [
                            if (video.formattedDuration.isNotEmpty)
                              video.formattedDuration,
                            _fmtDate(video.publishedAt),
                          ].join('  ·  '),
                          style: TextStyle(
                            color: sec.withValues(alpha: 0.5),
                            fontSize: 11.sp,
                          ),
                        ),

                        // HD Rozeti
                        if (video.isHd) ...[
                          SizedBox(width: 8.w),
                          Container(
                            padding: EdgeInsets.symmetric(
                              horizontal: 5.w,
                              vertical: 2.h,
                            ),
                            decoration: BoxDecoration(
                              color: _ytRed.withValues(alpha: 0.12),
                              borderRadius: BorderRadius.circular(3.r),
                            ),
                            child: Text(
                              'HD',
                              style: TextStyle(
                                color: _ytRed,
                                fontSize: 9.sp,
                                fontWeight: FontWeight.w800,
                                letterSpacing: 0.5,
                              ),
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  // ─────────────────────────────────────────────────────────────────────
  // İstatistik kalemi: ikon + kalın değer + küçük etiket
  // ─────────────────────────────────────────────────────────────────────
  Widget _buildStat({
    required IconData icon,
    required String value,
    required String label,
    required Color sec,
  }) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 14.sp, color: sec.withValues(alpha: 0.55)),
        SizedBox(width: 4.w),
        Text(
          value,
          style: TextStyle(
            color: sec.withValues(alpha: 0.8),
            fontSize: 13.sp,
            fontWeight: FontWeight.w600,
          ),
        ),
        SizedBox(width: 2.w),
        Text(
          label,
          style: TextStyle(color: sec.withValues(alpha: 0.4), fontSize: 10.sp),
        ),
      ],
    );
  }
}
