// lib/presentation/screens/home/widgets/tabs/discover_tab/discover_tab_widget.dart

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../../../../../../app/routes/app_routes.dart';
import '../../../../../../app/themes/app_theme.dart';
import '../../../../../controllers/home_controller.dart';
import '../home_tab/videos/video_sections_config.dart';

class DiscoverTabWidget extends StatelessWidget {
  const DiscoverTabWidget({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.find<HomeController>();

    return Scaffold(
      backgroundColor: AppTheme.bg(context),
      body: SafeArea(
        child: Obx(() {
          return RefreshIndicator(
            color: Theme.of(context).colorScheme.primary,
            onRefresh: controller.loadVideoSections,
            child: CustomScrollView(
              slivers: [
                // ── AppBar ───────────────────────────────────────────────
                SliverAppBar(
                  floating: true,
                  snap: true,
                  backgroundColor: AppTheme.bg(context),
                  automaticallyImplyLeading: false,
                  title: Row(
                    children: [
                      Container(
                        width: 32.w,
                        height: 32.h,
                        decoration: BoxDecoration(
                          color: Theme.of(context).colorScheme.primary,
                          borderRadius: BorderRadius.circular(8.r),
                        ),
                        child: Icon(
                          Icons.explore_rounded,
                          color: Theme.of(context).colorScheme.onPrimary,
                          size: 18.sp,
                        ),
                      ),
                      SizedBox(width: 10.w),
                      Text(
                        'Keşfet',
                        style:
                            Theme.of(context).textTheme.titleLarge?.copyWith(
                                  fontWeight: FontWeight.bold,
                                ),
                      ),
                    ],
                  ),
                  actions: [
                    IconButton(
                      icon: Icon(Icons.search_rounded, size: 24.sp),
                      onPressed: () => Get.toNamed(AppRoutes.search),
                    ),
                  ],
                ),

                // ── 6 Video Seksiyonu ────────────────────────────────────
                SliverToBoxAdapter(
                  child: Padding(
                    padding: EdgeInsets.only(top: 16.h, bottom: 24.h),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: buildVideoSections(
                        configs: videoSectionConfigs,
                        allVideoItems: [
                          controller.videosTrending.toList(),
                          controller.videosMostWatched.toList(),
                          controller.videosMostLiked.toList(),
                          controller.videosMostFavorited.toList(),
                          controller.videosMostCommented.toList(),
                          controller.videosNewUndiscovered.toList(),
                        ],
                        isLoading: controller.isVideoSectionsLoading.value,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          );
        }),
      ),
    );
  }
}
