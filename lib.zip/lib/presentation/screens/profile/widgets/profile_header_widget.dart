// lib/presentation/screens/profile/widgets/profile_header/profile_header_widget.dart

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';

import '../../../../../app/routes/app_routes.dart';
import '../../../../../app/themes/app_theme.dart';
import '../../../../controllers/profile_controller.dart';
import 'stat_chip_widget.dart';
import 'stat_divider_widget.dart';

// Banner + üste taşan avatarın boyut sabitleri. Header'ın toplam
// yüksekliği (SliverAppBar.expandedHeight) profile_view_widget.dart'ta
// bu sabitlere göre hesaplanır — ikisi senkron kalmalı.
const double kProfileBannerHeight = 96;
const double kProfileAvatarSize = 88;

class ProfileHeaderWidget extends StatelessWidget {
  final ProfileController controller;
  const ProfileHeaderWidget({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      final profile = controller.profile.value;
      final stats = controller.stats.value;
      final isOwn = controller.isOwnProfile;

      return Container(
        color: AppTheme.bg(context),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            // ── Kapak (banner) + üste taşan avatar ───────────────────────
            SizedBox(
              height: kProfileBannerHeight.h + kProfileAvatarSize.w / 2,
              child: Stack(
                clipBehavior: Clip.none,
                children: [
                  _CoverBanner(height: kProfileBannerHeight.h),
                  Positioned(
                    bottom: 0,
                    left: 0,
                    right: 0,
                    child: Center(
                      child: _AvatarWidget(
                        avatarUrl: profile?.avatarUrl,
                        username: profile?.username ?? 'U',
                        isOwnProfile: isOwn,
                        isUploading: controller.isUploadingAvatar.value,
                        size: kProfileAvatarSize.w,
                        onTap: () => _showAvatarSourceSheet(context, controller),
                      ),
                    ),
                  ),
                ],
              ),
            ),

            SizedBox(height: 12.h),

            // ── Kullanıcı adı ────────────────────────────────────────────
            Text(
              (profile?.fullName?.isNotEmpty ?? false)
                  ? profile!.fullName!
                  : (profile?.username ?? 'Kullanıcı'),
              style: TextStyle(
                color: AppTheme.textPri(context),
                fontSize: 19.sp,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),

            // ── @kullanıcı adı (tam isim gösterildiyse ikinci satır) ───────
            if ((profile?.fullName?.isNotEmpty ?? false) &&
                (profile?.username?.isNotEmpty ?? false)) ...[
              SizedBox(height: 3.h),
              Text(
                '@${profile!.username}',
                style: TextStyle(
                  color: AppTheme.textSec(context),
                  fontSize: 13.sp,
                ),
              ),
            ],

            if (profile != null) ...[
              SizedBox(height: 4.h),
              Text(
                _memberSinceLabel(profile.createdAt),
                style: TextStyle(
                  color: AppTheme.textSec(context).withValues(alpha: 0.75),
                  fontSize: 11.5.sp,
                ),
              ),
            ],

            // ── Profili Düzenle butonu ──────────────────────────────────
            if (isOwn) ...[
              SizedBox(height: 14.h),
              _EditProfileButton(),
            ],

            // ── Özet istatistik şeridi ──────────────────────────────────
            if (isOwn) ...[
              SizedBox(height: 16.h),
              _StatsRow(stats: stats),
            ],

            SizedBox(height: 10.h),
          ],
        ),
      );
    });
  }

  String _memberSinceLabel(DateTime date) {
    const months = [
      'Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran',
      'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık',
    ];
    final monthName = months[(date.month - 1).clamp(0, 11)];
    return '$monthName ${date.year}\'den beri üye';
  }
}

// ─── Kapak (Banner) ──────────────────────────────────────────────────────

class _CoverBanner extends StatelessWidget {
  final double height;
  const _CoverBanner({required this.height});

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.vertical(bottom: Radius.circular(26.r)),
      child: SizedBox(
        height: height,
        width: double.infinity,
        child: DecoratedBox(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [AppTheme.primaryColor, Color(0xFF0F5C2A)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          child: Stack(
            clipBehavior: Clip.none,
            children: [
              Positioned(
                right: -26.w,
                top: -30.h,
                child: _Blob(size: 130.w, opacity: 0.16),
              ),
              Positioned(
                left: -20.w,
                bottom: -34.h,
                child: _Blob(size: 96.w, opacity: 0.14),
              ),
              Positioned(
                left: 60.w,
                top: -18.h,
                child: _Blob(size: 46.w, opacity: 0.10),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Blob extends StatelessWidget {
  final double size;
  final double opacity;
  const _Blob({required this.size, required this.opacity});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: Colors.white.withValues(alpha: opacity),
      ),
    );
  }
}

// ─── Profili Düzenle Butonu ─────────────────────────────────────────────

class _EditProfileButton extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return OutlinedButton.icon(
      onPressed: () => Get.toNamed(AppRoutes.editProfile),
      icon: Icon(Icons.edit_outlined, size: 15.sp),
      label: Text('Profili Düzenle', style: TextStyle(fontSize: 12.5.sp)),
      style: OutlinedButton.styleFrom(
        foregroundColor: AppTheme.textPri(context),
        side: BorderSide(color: AppTheme.surface(context), width: 1.2.w),
        padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
        minimumSize: Size(0, 0),
        tapTargetSize: MaterialTapTargetSize.shrinkWrap,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20.r),
        ),
      ),
    );
  }
}

// ─── Özet İstatistik Şeridi ─────────────────────────────────────────────

class _StatsRow extends StatelessWidget {
  final dynamic stats; // UserStatsModel?
  const _StatsRow({required this.stats});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 20.w),
      padding: EdgeInsets.symmetric(vertical: 12.h),
      decoration: BoxDecoration(
        color: AppTheme.card(context),
        borderRadius: BorderRadius.circular(16.r),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          Expanded(
            child: StatChipWidget(
              icon: Icons.play_circle_rounded,
              count: stats?.totalWatched ?? 0,
              label: 'İzlenen',
            ),
          ),
          const StatDividerWidget(),
          Expanded(
            child: StatChipWidget(
              icon: Icons.thumb_up_alt_rounded,
              count: stats?.totalLiked ?? 0,
              label: 'Beğenilen',
            ),
          ),
          const StatDividerWidget(),
          Expanded(
            child: StatChipWidget(
              icon: Icons.favorite_rounded,
              count: stats?.totalFavorited ?? 0,
              label: 'Favori',
            ),
          ),
          const StatDividerWidget(),
          Expanded(
            child: StatChipWidget(
              icon: Icons.chat_bubble_rounded,
              count: stats?.totalCommented ?? 0,
              label: 'Yorum',
            ),
          ),
        ],
      ),
    );
  }
}

Future<void> _pickAndNotify(ProfileController controller, ImageSource source) async {
  await controller.pickAndUploadAvatar(source: source);
  if (controller.successMessage.value != null) {
    Get.snackbar('Başarılı', controller.successMessage.value!);
    controller.successMessage.value = null;
  } else if (controller.errorMessage.value != null) {
    Get.snackbar('Hata', controller.errorMessage.value!);
    controller.errorMessage.value = null;
  }
}

// ─── Avatar Kaynağı Seçim Sheet'i ───────────────────────────────────────────

void _showAvatarSourceSheet(BuildContext context, ProfileController controller) {
  if (!controller.isOwnProfile || controller.isUploadingAvatar.value) return;

  Get.bottomSheet(
    SafeArea(
      child: Container(
        decoration: BoxDecoration(
          color: AppTheme.card(context),
          borderRadius: BorderRadius.vertical(top: Radius.circular(20.r)),
        ),
        padding: EdgeInsets.symmetric(vertical: 12.h),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(height: 8.h),
            Text(
              'Profil Fotoğrafı',
              style: TextStyle(
                color: AppTheme.textPri(context),
                fontSize: 16.sp,
                fontWeight: FontWeight.w600,
              ),
            ),
            SizedBox(height: 8.h),
            ListTile(
              leading: Icon(Icons.photo_camera_outlined, color: AppTheme.textPri(context)),
              title: Text('Kameradan Çek', style: TextStyle(color: AppTheme.textPri(context), fontSize: 14.sp)),
              onTap: () {
                Get.back();
                _pickAndNotify(controller, ImageSource.camera);
              },
            ),
            ListTile(
              leading: Icon(Icons.photo_library_outlined, color: AppTheme.textPri(context)),
              title: Text('Galeriden Seç', style: TextStyle(color: AppTheme.textPri(context), fontSize: 14.sp)),
              onTap: () {
                Get.back();
                _pickAndNotify(controller, ImageSource.gallery);
              },
            ),
            SizedBox(height: 8.h),
          ],
        ),
      ),
    ),
  );
}

// ─── Avatar Widget ─────────────────────────────────────────────────────────

class _AvatarWidget extends StatelessWidget {
  final String? avatarUrl;
  final String username;
  final bool isOwnProfile;
  final bool isUploading;
  final double size;
  final VoidCallback onTap;

  const _AvatarWidget({
    required this.avatarUrl,
    required this.username,
    required this.isOwnProfile,
    required this.isUploading,
    required this.onTap,
    this.size = 80,
  });

  @override
  Widget build(BuildContext context) {
    final hasImage = avatarUrl != null && avatarUrl!.isNotEmpty;
    final badgeSize = size * 0.32;

    return GestureDetector(
      onTap: isOwnProfile ? onTap : null,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          Container(
            width: size,
            height: size,
            padding: EdgeInsets.all(3.w),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: AppTheme.bg(context),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.25),
                  blurRadius: 14.r,
                  offset: Offset(0, 5.h),
                ),
              ],
            ),
            child: Container(
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  colors: [AppTheme.primaryColor, Color(0xFF158a3e)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
              child: hasImage
                  ? ClipOval(
                      child: CachedNetworkImage(
                        imageUrl: avatarUrl!,
                        fit: BoxFit.cover,
                        width: size,
                        height: size,
                        errorWidget: (_, __, ___) => _InitialLetter(username: username, size: size),
                      ),
                    )
                  : _InitialLetter(username: username, size: size),
            ),
          ),

          // ── Yükleniyor overlay'i ─────────────────────────────────────────
          if (isUploading)
            Positioned.fill(
              child: ClipOval(
                child: Container(
                  color: Colors.black.withValues(alpha: 0.45),
                  child: Center(
                    child: SizedBox(
                      width: 26.w,
                      height: 26.w,
                      child: const CircularProgressIndicator(
                        strokeWidth: 2.5,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              ),
            ),

          // ── Kamera rozeti (sadece kendi profilimizde) ─────────────────────
          if (isOwnProfile && !isUploading)
            Positioned(
              right: -2.w,
              bottom: -2.h,
              child: Container(
                width: badgeSize,
                height: badgeSize,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: AppTheme.primaryColor,
                  border: Border.all(color: AppTheme.bg(context), width: 2.w),
                ),
                child: Icon(Icons.photo_camera_rounded, color: Colors.white, size: badgeSize * 0.5),
              ),
            ),
        ],
      ),
    );
  }
}

class _InitialLetter extends StatelessWidget {
  final String username;
  final double size;
  const _InitialLetter({required this.username, this.size = 80});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        username.isNotEmpty ? username[0].toUpperCase() : 'U',
        style: TextStyle(
          color: Colors.white,
          fontSize: size * 0.4,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}