import '../datasources/remote/supabase_datasource.dart';
import '../datasources/local/local_datasource.dart';
import '../models/profile_model.dart';
import '../models/user_settings_model.dart';

class AuthRepository {
  final SupabaseDataSource _supabase;
  final LocalDataSource _local;

  AuthRepository({
    required SupabaseDataSource supabase,
    required LocalDataSource local,
  })  : _supabase = supabase,
        _local = local;

  bool get isLoggedIn => _supabase.currentUser != null;
  String? get currentUserId => _supabase.currentUser?.id;
  Stream get authStateChanges => _supabase.authStateChanges;

  Future<void> signUp({
    required String email,
    required String password,
    required String username,
  }) async {
    await _supabase.signUp(
      email: email,
      password: password,
      username: username,
    );
  }

  Future<void> signIn({
    required String email,
    required String password,
  }) async {
    await _supabase.signIn(
      email: email,
      password: password,
    );
  }

  Future<void> signOut() async {
    // FIX: Çıkışta user_settings cache'ini temizle
    await _local.clearUserSettings();
    await _supabase.signOut();
  }

  Future<ProfileModel?> getProfile() async {
    final userId = currentUserId;
    if (userId == null) return null;
    return await _supabase.getProfile(userId);
  }

  Future<void> updateProfile(ProfileModel profile) async {
    await _supabase.updateProfile(profile);
  }

  // FIX: getUserSettings artık önce local cache'e bakıyor.
  // Cache yoksa Supabase'den çekip cache'e kaydediyor.
  Future<UserSettingsModel?> getUserSettings() async {
    final userId = currentUserId;
    if (userId == null) return null;

    final cached = await _local.getCachedUserSettings();
    if (cached != null) {
      return UserSettingsModel.fromSupabase(cached);
    }

    final settings = await _supabase.getUserSettings(userId);
    if (settings != null) {
      await _local.cacheUserSettings(settings.toSupabase());
    }
    return settings;
  }

  // FIX: Ayar güncellenince cache de güncelleniyor.
  Future<void> updateUserSettings(UserSettingsModel settings) async {
    await _supabase.updateUserSettings(settings);
    await _local.cacheUserSettings(settings.toSupabase());
  }

  Future<bool> isOnboardingCompleted() async {
    final userId = currentUserId;
    if (userId == null) return await _local.isOnboardingCompleted();
    return await _supabase.isOnboardingCompleted(userId);
  }

  Future<void> completeOnboarding() async {
    await _local.setOnboardingCompleted();
    final userId = currentUserId;
    if (userId != null) {
      await _supabase.completeOnboarding(userId);
    }
  }
}
