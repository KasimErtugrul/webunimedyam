// lib/core/responsive.dart
//
// Merkezi responsive/adaptive breakpoint yardımcı sınıfı.
//
// KÖK SEBEP HATIRLATMASI: flutter_screenutil'in .w/.h/.sp değerleri
// designSize (375x812, telefon) baz alınarak LİNEER scale ediyor. Bu, aynı
// form-factor içindeki (telefon-telefon) küçük farkları düzeltmek için
// doğrudur; ama telefon → tablet gibi FARKLI form-factor'lar arasında kart
// genişlikleri orantısız büyüyüp overflow'a yol açar.
//
// Bu dosyadan sonraki kural: ScreenUtil (.w/.h/.r/.sp) sadece AYNI
// form-factor içi ince ayarlar (padding, ikon boyutu, spacing, köşe
// yarıçapı) için kullanılmaya devam eder. Sayfa İSKELETİ (kaç sütun, hangi
// bileşen nerede duruyor, shorts'un yönü/konumu gibi kompozisyon kararları)
// SADECE bu sınıf (MediaQuery tabanlı breakpoint mantığı) ile verilir.
// Projede hiçbir yerde ham `MediaQuery.sizeOf(context).width >= 600` gibi
// bir karşılaştırma TEKRARLANMAMALI — her zaman Responsive.* üzerinden gidin.

import 'package:flutter/widgets.dart';

/// Cihaz/ekran genişliğine göre kaba kategori.
enum DeviceType { mobile, tablet, desktop }

class Responsive {
  Responsive._();

  /// >= bu genişlikte "tablet" kabul edilir (ör. iPad mini portrait ~768,
  /// katlanabilir açık hâli, küçük Android tabletler).
  ///
  /// VARSAYIM: Proje sahibiyle teyit edilmedi; makul bir varsayılan olarak
  /// seçildi. Değişmesi gerekirse burada TEK bir yerden güncellenir.
  static const double tabletBreakpoint = 600;

  /// >= bu genişlikte "desktop" kabul edilir (ör. masaüstü web/pencere,
  /// büyük tablet landscape).
  ///
  /// VARSAYIM: Proje sahibiyle teyit edilmedi; makul bir varsayılan olarak
  /// seçildi.
  static const double desktopBreakpoint = 1024;

  /// Verilen genişliğe göre [DeviceType] döndürür. Genellikle
  /// [type] üzerinden BuildContext ile çağırmak yeterlidir; bu, testlerde
  /// veya LayoutBuilder constraint'i elde varken doğrudan genişlik
  /// vermek için kullanılır.
  static DeviceType typeOfWidth(double width) {
    if (width >= desktopBreakpoint) return DeviceType.desktop;
    if (width >= tabletBreakpoint) return DeviceType.tablet;
    return DeviceType.mobile;
  }

  /// Mevcut [BuildContext]'in ekran genişliğine göre [DeviceType].
  static DeviceType type(BuildContext context) {
    return typeOfWidth(MediaQuery.sizeOf(context).width);
  }

  static bool isMobile(BuildContext context) =>
      type(context) == DeviceType.mobile;

  /// NOT: "tablet" burada >= tabletBreakpoint anlamına gelir; yani desktop
  /// genişlikleri de dahildir (isTablet == !isMobile). Sadece tablet VE
  /// desktop'ı ayırmak isteyen çağıran kod isDesktop ile birlikte kullanmalı.
  static bool isTablet(BuildContext context) =>
      type(context) != DeviceType.mobile;

  static bool isDesktop(BuildContext context) =>
      type(context) == DeviceType.desktop;

  /// Ekran genişliğine + kayan noktalı bir eşiğe göre iki (veya üç) değer
  /// arasından seçim yapan generic yardımcı.
  ///
  /// `tablet` verilmezse mobile değeri; `desktop` verilmezse tablet (yoksa
  /// mobile) değeri kullanılır — yani her kademe bir öncekine "düşer"
  /// (fallback), her ekran tipi için ayrı değer vermek zorunlu değildir.
  static T value<T>(
    BuildContext context, {
    required T mobile,
    T? tablet,
    T? desktop,
  }) {
    switch (type(context)) {
      case DeviceType.desktop:
        return desktop ?? tablet ?? mobile;
      case DeviceType.tablet:
        return tablet ?? mobile;
      case DeviceType.mobile:
        return mobile;
    }
  }
}
